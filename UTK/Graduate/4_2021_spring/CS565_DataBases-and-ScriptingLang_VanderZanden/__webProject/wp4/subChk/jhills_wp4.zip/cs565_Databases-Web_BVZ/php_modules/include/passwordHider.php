<?php
    //IMPORTANT: do NOT include this php file with submission!!!
    $pwHidden="theflesh0101"
?>